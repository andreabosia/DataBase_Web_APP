package exceptions;

public class UsernameException extends Exception {
	private static final long serialVersionUID = 1L;

	public UsernameException(String message) {
		super(message);
	}
	
}
