package exceptions;

public class PhoneInternetException extends Exception {
	private static final long serialVersionUID = 1L;

	public PhoneInternetException(String message) {
		super(message);
	}
	
	

}
