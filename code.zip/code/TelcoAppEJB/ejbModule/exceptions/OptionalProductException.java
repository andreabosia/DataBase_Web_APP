package exceptions;

public class OptionalProductException extends Exception {
	private static final long serialVersionUID = 1L;

	public OptionalProductException(String message) {
		super(message);
	}
	
}
