package exceptions;

public class ServicePackageException extends Exception{
	private static final long serialVersionUID = 1L;

	public ServicePackageException(String message) {
		super(message);
	}
}
