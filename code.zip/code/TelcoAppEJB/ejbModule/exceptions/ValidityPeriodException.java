package exceptions;

public class ValidityPeriodException extends Exception {
	private static final long serialVersionUID = 1L;

	public ValidityPeriodException(String message) {
		super(message);
	}

}
