package materializedviews;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import entities.ServicePackage;

@Entity
@Table(name = "tot_sales_package", schema = "db_telco")
@NamedQuery(name = "TotSalesPackage.findAll", query = "SELECT i FROM TotSalesPackage i")

public class TotSalesPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToOne
	@JoinColumn(name = "service_package")
	private ServicePackage servicePackage;

	@Column(name = "tot_sales")
	private Double totSales;
	
	@Column(name = "sales_with_op_products")
	private Double salesWithOpProduct;

	public TotSalesPackage() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ServicePackage getServicePackage() {
		return servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public Double getTotSales() {
		return totSales;
	}

	public void setTotSales(Double totSales) {
		this.totSales = totSales;
	}

	public Double getSalesWithOpProduct() {
		return salesWithOpProduct;
	}

	public void setSalesWithOpProduct(Double salesWithOpProduct) {
		this.salesWithOpProduct = salesWithOpProduct;
	}

	
}
