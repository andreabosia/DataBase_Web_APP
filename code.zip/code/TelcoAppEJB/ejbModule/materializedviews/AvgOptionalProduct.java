package materializedviews;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import entities.ServicePackage;

@Entity
@Table(name = "avg_optional_product", schema = "db_telco")
@NamedQuery(name = "AvgOptionalProduct.findAll", query = "SELECT i FROM AvgOptionalProduct i")

public class AvgOptionalProduct implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToOne
	@JoinColumn(name = "service_package")
	private ServicePackage servicePackage;
	
	@Column(name = "avg_op_products")
	private int avgOpProducts;

	public AvgOptionalProduct() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ServicePackage getServicePackage() {
		return servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public int getAvgOpProducts() {
		return avgOpProducts;
	}

	public void setAvgOpProducts(int avgOpProducts) {
		this.avgOpProducts = avgOpProducts;
	}
	
}
