package materializedviews;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import entities.OptionalProduct;

@Entity
@Table(name = "best_seller", schema = "db_telco")
@NamedQuery(name = "BestSeller.findBestSeller", query = "SELECT bs FROM BestSeller bs")

public class BestSeller implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToOne
	@JoinColumn(name = "op_product")
	private OptionalProduct bestSeller;
	
	@Column(name = "tot_sale")
	private double totSale;

	public BestSeller() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public OptionalProduct getBestSeller() {
		return bestSeller;
	}

	public void setBestSeller(OptionalProduct bestSeller) {
		this.bestSeller = bestSeller;
	}

	public double getTotSale() {
		return totSale;
	}

	public void setTotSale(double totSale) {
		this.totSale = totSale;
	}
	

}
