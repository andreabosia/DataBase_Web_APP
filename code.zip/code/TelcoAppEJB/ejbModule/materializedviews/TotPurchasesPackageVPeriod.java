package materializedviews;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import entities.ServicePackage;
import entities.ValidityPeriod;

@Entity
@Table(name = "tot_purchases_package_vperiod", schema = "db_telco")
@NamedQuery(name = "TotPurchasesPackageVPeriod.findAll", query = "SELECT i FROM TotPurchasesPackageVPeriod i")

public class TotPurchasesPackageVPeriod implements Serializable{
private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToOne
	@JoinColumn(name = "service_package")
	private ServicePackage servicePackage;
	
	@OneToOne
	@JoinColumn(name = "validity_period")
	private ValidityPeriod validityPeriod;
	
	@Column(name="tot_purchases")
	private int totPurchases;

	public TotPurchasesPackageVPeriod() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ServicePackage getServicePackage() {
		return servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public ValidityPeriod getValidityPeriod() {
		return validityPeriod;
	}

	public void setValidityPeriod(ValidityPeriod validityPeriod) {
		this.validityPeriod = validityPeriod;
	}

	public int getTotPurchases() {
		return totPurchases;
	}

	public void setTotPurchases(int totPurchases) {
		this.totPurchases = totPurchases;
	}
	
	
}
