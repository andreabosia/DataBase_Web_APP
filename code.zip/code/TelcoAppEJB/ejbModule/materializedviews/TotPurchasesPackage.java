package materializedviews;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import entities.ServicePackage;

@Entity
@Table(name = "tot_purchases_package", schema = "db_telco")
@NamedQuery(name = "TotPurchasesPackage.findAll", query = "SELECT i FROM TotPurchasesPackage i")

public class TotPurchasesPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "tot_purchases")
	private int totPurchases;

	@OneToOne
	@JoinColumn(name = "service_package")
	private ServicePackage servicePackage;

	public TotPurchasesPackage() {
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setTotPurchases(int totPurchases) {
		this.totPurchases = totPurchases;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public int getId() {
		return id;
	}

	public int getTotPurchases() {
		return totPurchases;
	}

	public ServicePackage getServicePackage() { /* WARNING: OPTIONAL PRODUCTS LOADED WITH PACKAGE */
		return servicePackage;
	}

}
