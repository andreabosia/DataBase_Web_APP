package entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "service_package", schema = "db_telco")
@NamedQueries({ 
	@NamedQuery(name = "ServicePackage.findAll", query = "SELECT sp FROM ServicePackage sp"),
	@NamedQuery(name = "ServicePackage.findByName", query = "SELECT sp FROM ServicePackage sp WHERE sp.name = :name") })

public class ServicePackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;

	@ManyToOne
	@JoinColumn(name = "id_fixedphone")
	private FixedPhone fixedPhone;

	@ManyToOne
	@JoinColumn(name = "id_mobilephone")
	private MobilePhone mobilePhone;

	@ManyToOne
	@JoinColumn(name = "id_fixedinternet")
	private FixedInternet fixedInternet;

	@ManyToOne
	@JoinColumn(name = "id_mobileinternet")
	private MobileInternet mobileInternet;

	@OneToMany(mappedBy = "servicePackage")
	private Collection<Order> orders;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "service_package_validity_period", 
				joinColumns = @JoinColumn(name = "id_servicepackage"), 
				inverseJoinColumns = @JoinColumn(name = "id_validityperiod"))
	private List<ValidityPeriod> validityPeriods;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "service_package_optional_product", 
				joinColumns = @JoinColumn(name = "id_servicepackage"), 
				inverseJoinColumns = @JoinColumn(name = "id_optionalproduct"))
	private List<OptionalProduct> optionalProducts;


	public ServicePackage() {
	}

	public ServicePackage(String name, FixedPhone fixedPhone, MobilePhone mobilePhone, FixedInternet fixedInternet,
			MobileInternet mobileInternet, List<ValidityPeriod> validityPeriods, List<OptionalProduct> optionalProducts) {
		this.name = name;
		this.fixedPhone = fixedPhone;
		this.mobilePhone = mobilePhone;
		this.fixedInternet = fixedInternet;
		this.mobileInternet = mobileInternet;
		this.validityPeriods = validityPeriods;
		this.optionalProducts = optionalProducts;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public FixedPhone getFixedPhone() {
		return fixedPhone;
	}

	public void setFixedPhone(FixedPhone fixedPhone) {
		this.fixedPhone = fixedPhone;
	}

	public MobilePhone getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(MobilePhone mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public FixedInternet getFixedInternet() {
		return fixedInternet;
	}

	public void setFixedInternet(FixedInternet fixedInternet) {
		this.fixedInternet = fixedInternet;
	}

	public MobileInternet getMobileInternet() {
		return mobileInternet;
	}

	public void setMobileInternet(MobileInternet mobileInternet) {
		this.mobileInternet = mobileInternet;
	}

	public Collection<Order> getOrders() {
		return orders;
	}

	public List<ValidityPeriod> getValidityPeriods() {
		return validityPeriods;
	}

	public void setValidityPeriods(List<ValidityPeriod> validityPeriods) {
		this.validityPeriods = validityPeriods;
	}

	public List<OptionalProduct> getOptionalProducts() {
		return optionalProducts;
	}

	public void setOptionalProducts(List<OptionalProduct> optionalProducts) {
		this.optionalProducts = optionalProducts;
	}

}
