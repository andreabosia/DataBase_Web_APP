package entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "auditing_table", schema = "db_telco")
@NamedQuery(name="AuditingTable.findAll",query="SELECT at FROM AuditingTable at")
public class AuditingTable implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private float amount;
	
	@Column(name = "rejection_date_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date rejectionDateTime;

	@OneToOne
	@JoinColumns({
		@JoinColumn(name="id_user", referencedColumnName="id"),
		@JoinColumn(name="username", referencedColumnName="username"),
		@JoinColumn(name="email", referencedColumnName="email")
	})
	private User user;

	
	public AuditingTable() {
	}
	
	public AuditingTable(float amount, Date rejectionDateTime, User user) {
		super();
		this.amount = amount;
		this.rejectionDateTime = rejectionDateTime;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public Date getRejectionDateTime() {
		return rejectionDateTime;
	}

	public void setRejectionDateTime(Date rejectionDateTime) {
		this.rejectionDateTime = rejectionDateTime;
	}

	public User getUser() {
		return user;
	}

}
