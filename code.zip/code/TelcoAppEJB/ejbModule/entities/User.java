package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "user_table", schema = "db_telco")
@NamedQueries({
		@NamedQuery(name = "User.checkCredentials", query = "SELECT u FROM User u  WHERE u.username = :username and u.password = :password"),
		@NamedQuery(name = "User.findByEmailOrUsername", query = "SELECT u FROM User u WHERE u.email = :email or u.username = :username"),
		@NamedQuery(name = "User.findInsolventUsers", query = "SELECT u FROM User u WHERE u.insolvent = true")})

public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String username;

	private String password;

	private String email;

	@Column(name = "num_failed_payments")
	private int numFailedPayments;

	@Column(name = "is_insolvent")
	private boolean insolvent;

	@OneToOne(mappedBy = "user") 
	private AuditingTable auditingTableAlert;

	@OneToMany(mappedBy = "user")
	private Collection<Order> orders;

	public User() {
	}

	public User(String username, String password, String email) {
		this.username = username;
		this.password = password;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getNumFailedPayments() {
		return numFailedPayments;
	}

	public void setNumFailedPayments(int numFailedPayments) {
		this.numFailedPayments = numFailedPayments;
	}

	public void increaseNumFailedPayments() {
		this.numFailedPayments = numFailedPayments + 1;
	}
	
	public void decreaseNumFailedPayments(int ordFailures) {
		if(this.numFailedPayments >= ordFailures)
			this.numFailedPayments = numFailedPayments - ordFailures;
		else
			this.numFailedPayments = 0;
	}
	
	public boolean isInsolvent() {
		return insolvent;
	}

	public void setInsolvent(boolean insolvent) {
		this.insolvent = insolvent;
	}

	public AuditingTable getAuditingTableAlert() {
		return auditingTableAlert;
	}

	public Collection<Order> getOrders() {
		return orders;
	}

}