package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "optional_product", schema = "db_telco")
@NamedQueries({ @NamedQuery(name = "OptionalProduct.findAll", query = "SELECT op FROM OptionalProduct op"),
				@NamedQuery(name = "OptionalProduct.findByName", query = "SELECT op FROM OptionalProduct op WHERE op.name = :name") })

public class OptionalProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;

	@Column(name = "monthly_fee")
	private float monthlyFee;

	@ManyToMany(mappedBy = "optionalProducts") 
	private Collection <ServicePackage> servicePackages;
	 
	@ManyToMany(mappedBy = "optionalProducts")
	private Collection<Order> orders;

	public OptionalProduct() {
	}

	public OptionalProduct(String name, float monthlyFee) {
		this.name = name;
		this.monthlyFee = monthlyFee;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getMonthlyFee() {
		return monthlyFee;
	}

	public void setMonthlyFee(float monthlyFee) {
		this.monthlyFee = monthlyFee;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof OptionalProduct) {
			OptionalProduct op = (OptionalProduct) obj;
			
			if(this.id == op.getId() && this.name == op.getName() && this.monthlyFee == op.getMonthlyFee())
				return true;
		}
		
		return false;
	}

	public Collection<ServicePackage> getServicePackages() { 
		return servicePackages; 
	}
	 
	public Collection<Order> getOrders() {
		return orders;
	}

}
