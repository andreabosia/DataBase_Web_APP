package entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;


@Entity
@Table(name = "orders", schema = "db_telco")
@NamedQueries({
	@NamedQuery(name = "Order.findRejectedOrders", query = "SELECT o FROM Order o  WHERE o.user = :user AND o.rejected = true"),
	@NamedQuery(name = "Order.findAllRejectedOrders", query = "SELECT o FROM Order o  WHERE o.rejected = true")})
public class Order implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="tot_amount")
	private float totAmount;
	
	private boolean rejected;
	
	@Column(name="creation_date_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDateTime;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name="num_failed_payments") /*UPDATE*/
	private int numFailedPayments;
	
	@ManyToOne
	@JoinColumn(name = "id_user")
	private User user;
	
	@OneToOne(mappedBy = "order")
	private ActivationSchedule activationSchedule;
	
	@ManyToOne
	@JoinColumn(name = "id_servicepackage")
	private ServicePackage servicePackage;
	
	@ManyToOne
	@JoinColumn(name = "id_validityperiod")
	private ValidityPeriod validityPeriod;
	
	@ManyToMany
	@JoinTable(name = "order_optional_product", 
				joinColumns = @JoinColumn(name = "id_order"),
				inverseJoinColumns = @JoinColumn(name = "id_optionalproduct"))
	private List<OptionalProduct> optionalProducts;
	
	
	public Order() {
	}
	
	public Order(float totAmount, Date creationDateTime, Date startDate, User user,
			ServicePackage servicePackage, ValidityPeriod validityPeriod, List<OptionalProduct> optionalProducts) {
		super();

		this.totAmount = totAmount;
		this.creationDateTime = creationDateTime;
		this.startDate = startDate;
		this.user = user;
		this.servicePackage = servicePackage;
		this.validityPeriod = validityPeriod;
		this.optionalProducts = optionalProducts;
	}
	
	public Order(float totAmount, Date creationDateTime, Date startDate, User user,
			ServicePackage servicePackage, ValidityPeriod validityPeriod) {
		super();

		this.totAmount = totAmount;
		this.creationDateTime = creationDateTime;
		this.startDate = startDate;
		this.user = user;
		this.servicePackage = servicePackage;
		this.validityPeriod = validityPeriod;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getTotAmount() {
		return totAmount;
	}

	public void setTotAmount(float totAmount) {
		this.totAmount = totAmount;
	}

	public boolean isRejected() {
		return rejected;
	}

	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}

	public Date getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(Date creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ActivationSchedule getActivationSchedule() {
		return activationSchedule;
	}

	public void setActivationSchedule(ActivationSchedule activationSchedule) {
		this.activationSchedule = activationSchedule;
	}

	public ServicePackage getServicePackage() {
		return servicePackage;
	}

	public void setServicePackage(ServicePackage servicePackage) {
		this.servicePackage = servicePackage;
	}

	public ValidityPeriod getValidityPeriod() {
		return validityPeriod;
	}

	public void setValidityPeriod(ValidityPeriod validityPeriod) {
		this.validityPeriod = validityPeriod;
	}

	public List<OptionalProduct> getOptionalProducts() {
		return optionalProducts;
	}

	public void setOptionalProducts(List<OptionalProduct> optionalProducts) {
		this.optionalProducts = optionalProducts;
	}

	public int getNumFailedPayments() {
		return numFailedPayments;
	}
	
	public void setNumFailedPayments(int numFailedPayments) {
		this.numFailedPayments = numFailedPayments;
	}
	
	public void increaseNumFailedPayments() {
		this.numFailedPayments = this.numFailedPayments + 1;
	}	
	

}
