package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "fixed_internet", schema = "db_telco")
@NamedQuery(name="FixedInternet.findAll",query="SELECT fi FROM FixedInternet fi")
public class FixedInternet implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;
	
	@Column(name = "num_giga")
	private int numGiga;
	
	@Column(name = "extra_giga_fee")
	private float extraGigaFee;
	
	@OneToMany(mappedBy = "fixedInternet")
	private Collection<ServicePackage> servicePackages;

	
	public FixedInternet() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumGiga() {
		return numGiga;
	}

	public void setNumGiga(int numGiga) {
		this.numGiga = numGiga;
	}

	public float getExtraGigaFee() {
		return extraGigaFee;
	}

	public void setExtraGigaFee(float extraGigaFee) {
		this.extraGigaFee = extraGigaFee;
	}

	public Collection<ServicePackage> getServicePackages() {
		return servicePackages;
	}

}

