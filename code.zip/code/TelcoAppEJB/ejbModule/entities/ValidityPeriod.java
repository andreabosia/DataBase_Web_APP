package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "validity_period", schema = "db_telco")
@NamedQuery(name = "ValidityPeriod.findAll", query = "SELECT vp FROM ValidityPeriod vp")
public class ValidityPeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "monthly_fee")
	private float monthlyFee;

	@Column(name = "num_months")
	private int numMonths;

	@OneToMany(mappedBy = "validityPeriod")
	private Collection<Order> orders;

	
	@ManyToMany (mappedBy = "validityPeriods") 
	private Collection<ServicePackage> servicePackages;
	

	public ValidityPeriod() {
	}

	public ValidityPeriod(int numMonths,float monthlyFee) {
		this.monthlyFee = monthlyFee;
		this.numMonths = numMonths;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getMonthlyFee() {
		return monthlyFee;
	}

	public void setMonthlyFee(float monthlyFee) {
		this.monthlyFee = monthlyFee;
	}

	public int getNumMonths() {
		return numMonths;
	}

	public void setNumMonths(int numMonths) {
		this.numMonths = numMonths;
	}

	public Collection<Order> getOrders() {
		return orders;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ValidityPeriod) {
			ValidityPeriod vp = (ValidityPeriod) obj;
			
			if(this.id == vp.getId() && this.monthlyFee == vp.monthlyFee && this.numMonths == vp.getNumMonths())
				return true;
		}
		
		return false;
	}

	
	public Collection<ServicePackage> getServicePackages() { 
		return servicePackages; 
	}
	

}
