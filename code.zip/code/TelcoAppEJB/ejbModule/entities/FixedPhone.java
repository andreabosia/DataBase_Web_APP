package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "fixed_phone", schema = "db_telco")
@NamedQuery(name="FixedPhone.findAll",query="SELECT fp FROM FixedPhone fp")
public class FixedPhone implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;
	
	@OneToMany(mappedBy = "fixedPhone")
	private Collection<ServicePackage> servicePackages;

	
	public FixedPhone() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<ServicePackage> getServicePackages() {
		return servicePackages;
	}

}
