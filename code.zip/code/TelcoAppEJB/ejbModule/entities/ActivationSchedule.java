package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


@Entity
@Table(name = "activation_schedule", schema = "db_telco")
public class ActivationSchedule implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "activation_date")
	private Date activationDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "deactivation_date")
	private Date deactivationDate;
	
	@OneToOne
	@JoinColumn(name = "id_order")
	private Order order;

	
	public ActivationSchedule() {
	}

	public ActivationSchedule( Date activationDate, Date deactivationDate, Order order) {
		super();
		this.activationDate = activationDate;
		this.deactivationDate = deactivationDate;
		this.order = order;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public Date getDeactivationDate() {
		return deactivationDate;
	}

	public void setDeactivationDate(Date deactivationDate) {
		this.deactivationDate = deactivationDate;
	}

	public Order getOrder() {
		return order;
	}
		
}
