package entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;

@Entity
@Table(name = "mobile_phone", schema = "db_telco")
@NamedQuery(name="MobilePhone.findAll",query="SELECT mp FROM MobilePhone mp")
public class MobilePhone implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;
	
	@Column(name = "num_minutes")
	private int numMinutes;
	
	@Column(name = "num_sms")
	private int numSms;
	
	@Column(name = "extra_min_fee")
	private float extraMinFee;
	
	@Column(name = "extra_sms_fee")
	private float extraSmsFee;
	
	@OneToMany(mappedBy = "mobilePhone")
	private Collection<ServicePackage> servicePackages;

	
	public MobilePhone() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumMinutes() {
		return numMinutes;
	}

	public void setNumMinutes(int numMinutes) {
		this.numMinutes = numMinutes;
	}

	public int getNumSms() {
		return numSms;
	}

	public void setNumSms(int numSms) {
		this.numSms = numSms;
	}

	public float getExtraMinFee() {
		return extraMinFee;
	}

	public void setExtraMinFee(float extraMinFee) {
		this.extraMinFee = extraMinFee;
	}

	public float getExtraSmsFee() {
		return extraSmsFee;
	}

	public void setExtraSmsFee(float extraSmsFee) {
		this.extraSmsFee = extraSmsFee;
	}

	public Collection<ServicePackage> getServicePackages() {
		return servicePackages;
	}
	
}
