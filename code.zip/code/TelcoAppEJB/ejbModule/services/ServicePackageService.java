package services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import java.util.ArrayList;
import java.util.List;

import entities.FixedInternet;
import entities.FixedPhone;
import entities.MobileInternet;
import entities.MobilePhone;
import entities.OptionalProduct;
import entities.ServicePackage;
import entities.ValidityPeriod;
import exceptions.ServicePackageException;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;

@Stateless
public class ServicePackageService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public ServicePackageService() {
	}

	
	public List<ServicePackage> findAllServicePackages() throws ServicePackageException {
		List<ServicePackage> servicesList = null;

		try {
			TypedQuery<ServicePackage> query = em.createNamedQuery("ServicePackage.findAll", ServicePackage.class);
			servicesList = query.getResultList();

		} catch (PersistenceException e) {
			throw new ServicePackageException("Can not load service packages");
		}
		return servicesList;
	}

	
	public ServicePackage findServicePackageById(int servicePackageId) {
		ServicePackage sp = em.find(ServicePackage.class, servicePackageId);
		return sp;
	}

	
	public void createServicePackage(String name, int fixedPhoneId, int mobilePhoneId, int fixedInternetId,
			int mobileInternetId, List<Integer> validityPeriodIds, List<Integer> optionalProductIds)
			throws ServicePackageException {
		
		// check that the name is unique
		List<ServicePackage> duplicates = em.createNamedQuery("ServicePackage.findByName", ServicePackage.class).setParameter("name", name).getResultList();
		if(!duplicates.isEmpty())
			throw new ServicePackageException("The specified name has already been used");
		
		// get services
		FixedPhone fp = em.find(FixedPhone.class, fixedPhoneId);
		MobilePhone mp = em.find(MobilePhone.class, mobilePhoneId);
		FixedInternet fi = em.find(FixedInternet.class, fixedInternetId);
		MobileInternet mi = em.find(MobileInternet.class, mobileInternetId);

		// get validity periods
		List<ValidityPeriod> vpList = new ArrayList<ValidityPeriod>();
		for (int vp : validityPeriodIds) {
			ValidityPeriod validityPeriod = em.find(ValidityPeriod.class, vp);
			if (validityPeriod != null)
				vpList.add(validityPeriod);
		}

		// create a new service package
		ServicePackage sp = null;
		if (!vpList.isEmpty()) {

			if (fp != null | mp != null | fi != null | mi != null) {
				sp = new ServicePackage(name, fp, mp, fi, mi, vpList, new ArrayList<OptionalProduct>());
			} else {
				throw new ServicePackageException("A package must contain at least one service");
			}

		} else {
			throw new ServicePackageException("A package must have at least one validity period");
		}

		// add optional products
		if(!optionalProductIds.isEmpty()) {
			for (int op : optionalProductIds) {
				OptionalProduct optionalProduct = em.find(OptionalProduct.class, op);
				if (optionalProduct != null)
					sp.getOptionalProducts().add(optionalProduct);
			}
		}

		// persist into the db
		try {
			em.persist(sp);
		} catch (PersistenceException e) {
			throw new PersistenceException(
					"An error has occurred during the service package creation, please retry later");
		}

	}

}
