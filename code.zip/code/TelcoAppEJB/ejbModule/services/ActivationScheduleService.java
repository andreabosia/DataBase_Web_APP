package services;

import java.util.Date;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.time.DateUtils;

import entities.ActivationSchedule;
import entities.Order;


@Stateless
public class ActivationScheduleService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;


	public ActivationScheduleService() {
	}

	
	public void createActivationSchedule( Date startDate, int numMonth, Order order) {
		
		Order ord = em.find(Order.class, order.getId());
		
		Date deactivationDate = DateUtils.addMonths(startDate, numMonth);
		ActivationSchedule activationSchedule = new ActivationSchedule(startDate, deactivationDate, ord);
		
		em.persist(activationSchedule);

	}

}
