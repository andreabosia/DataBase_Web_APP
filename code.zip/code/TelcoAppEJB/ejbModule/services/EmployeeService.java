package services;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.Employee;
import exceptions.CredentialsException;

@Stateless
public class EmployeeService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public EmployeeService() {
	}

	public Employee checkCredentials(String usrn, String pwd) throws CredentialsException {
		Employee e;
		try {
			e = em.createNamedQuery("Employee.checkCredentials", Employee.class).setParameter("username", usrn)
					.setParameter("password", pwd).getSingleResult();
		} catch (NoResultException ex) {
			e = null;
		} catch (PersistenceException ex) {
			throw new CredentialsException("Could not verify credentials");
		}
		return e;
	}

}
