package services;

import java.util.List;
import java.util.regex.Pattern;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.User;
import exceptions.*;

@Stateless
public class UserService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	private static final Pattern emailPattern = Pattern
			.compile("^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$");

	public UserService() {
	}

	public User findUserById(User user) {
		User usr = null;
		if( user == null)
			return usr;
		usr = em.find(User.class, user.getId());
		return usr;
	}
	
	public User checkCredentials(String usrn, String pwd) throws CredentialsException, NonUniqueResultException {
		User u;
		try {
			u = em.createNamedQuery("User.checkCredentials", User.class).setParameter("username", usrn)
					.setParameter("password", pwd).getSingleResult();
		} catch (NoResultException e) {
			u = null;
		} catch (PersistenceException e) {
			throw new CredentialsException("Could not verify credentials");
		}
		return u;
	}

	
	public User registerUser(String usrn, String email, String pwd)
			throws RegistrationException, EmailException, UsernameException, PasswordException {

		if (usrn == null || usrn.equals(""))
			throw new UsernameException("An username must be specified");
		if (email == null || email.equals(""))
			throw new EmailException("An email must be specified");
		else if (pwd == null || pwd.equals(""))
			throw new PasswordException("A password must be specified");

		// check if email format is valid

		if (!emailPattern.matcher(email).matches())
			throw new EmailException("The specified email is invalid");

		// check the password length
		// if (pwd.length() < 6)
		// throw new PasswordException("The password must contain al least 6
		// characters");

		// check if username or email already exist in the db

		List<User> duplicates = em.createNamedQuery("User.findByEmailOrUsername", User.class)
				.setParameter("email", email).setParameter("username", usrn).getResultList();

		if (!duplicates.isEmpty()) {
			User duplicate = duplicates.get(0);

			if (duplicate.getEmail().equals(email))
				throw new EmailException("The specified email has already been used");

			else if (duplicate.getUsername().equals(usrn))
				throw new UsernameException("The specified username has already been used");
		}

		// add new user into the db

		User user = new User(usrn, pwd, email);

		try {
			em.persist(user);
		} catch (Exception e) {
			throw new RegistrationException("An error has occurred during registration, please retry later");
		}
		return user;
	}

}
