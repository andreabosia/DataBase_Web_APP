package services;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.AuditingTable;
import entities.Order;
import entities.User;
import exceptions.SalesReportException;
import materializedviews.AvgOptionalProduct;
import materializedviews.BestSeller;
import materializedviews.TotPurchasesPackage;
import materializedviews.TotPurchasesPackageVPeriod;
import materializedviews.TotSalesPackage;

@Stateless
public class SalesReportService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public SalesReportService() {
	}

	
	// number of total purchases per package
	public List<TotPurchasesPackage> findAllPurchasesPackage() throws SalesReportException {
		List<TotPurchasesPackage> purchasesList = null;

		try {
			purchasesList = em.createNamedQuery("TotPurchasesPackage.findAll", TotPurchasesPackage.class).
					setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load number of purchases per package");
		}
		return purchasesList;
	}

	
	// number of total purchases per package and validity period
	public List<TotPurchasesPackageVPeriod> findAllPurchasesPackageVPeriod() throws SalesReportException {
		List<TotPurchasesPackageVPeriod> purchasesList = null;

		try {
			purchasesList = em.createNamedQuery("TotPurchasesPackageVPeriod.findAll", TotPurchasesPackageVPeriod.class)
					.setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load number of purchases per package and validity period");
		}
		return purchasesList;
	}

	
	// total value of sales per package with and without the optional products
	public List<TotSalesPackage> findAllSalesPackage() throws SalesReportException {
		List<TotSalesPackage> salesList = null;

		try {
			salesList = em.createNamedQuery("TotSalesPackage.findAll", TotSalesPackage.class)
					.setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load value of sales per package and optional product");
		}
		return salesList;
	}

	
	// average number of optional products sold together with each service package
	public List<AvgOptionalProduct> findAllAvgOpProduct() throws SalesReportException {
		List<AvgOptionalProduct> opProductsList = null;

		try {
			opProductsList = em.createNamedQuery("AvgOptionalProduct.findAll", AvgOptionalProduct.class)
					.setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load average number of optional products");
		}
		return opProductsList;
	}

	
	// list of insolvent users
	public List<User> findAllInsolventUsers() throws SalesReportException {
		List<User> insolventList = null;

		try {
			insolventList = em.createNamedQuery("User.findInsolventUsers", User.class).getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load list of insolvent users");
		}
		return insolventList;
	}

	
	// list of rejected orders
	public List<Order> findAllRejectedOrders() throws SalesReportException {
		List<Order> rejectedList = null;

		try {
			rejectedList = em.createNamedQuery("Order.findAllRejectedOrders", Order.class).getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load list of suspended orders");
		}
		return rejectedList;
	}

	
	// list of alerts
	public List<AuditingTable> findAllAlerts() throws SalesReportException {
		List<AuditingTable> alertList = null;

		try {
			alertList = em.createNamedQuery("AuditingTable.findAll", AuditingTable.class).getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load list of alerts");
		}
		return alertList;
	}
	
	
	// best seller optional product
	public BestSeller findBestSeller() throws SalesReportException {
		List<BestSeller> bestSeller = null;
		
		try {
			bestSeller = em.createNamedQuery("BestSeller.findBestSeller", BestSeller.class)
					.setHint("javax.persistence.cache.storeMode", "REFRESH").getResultList();
		} catch (PersistenceException e) {
			throw new SalesReportException("Cannot load best seller product");
		}
		if (bestSeller.size() > 0)
			return bestSeller.get(0);
		
		return null;
	}

}
