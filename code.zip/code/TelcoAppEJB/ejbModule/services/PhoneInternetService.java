package services;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.FixedInternet;
import entities.FixedPhone;
import entities.MobileInternet;
import entities.MobilePhone;
import exceptions.PhoneInternetException;

@Stateless
public class PhoneInternetService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public PhoneInternetService() {
	}
	
	
	public List<FixedInternet> findAllFixedInternetServices() throws PhoneInternetException{
		List<FixedInternet> fixedInternetList = null;
		try {
			fixedInternetList = em.createNamedQuery("FixedInternet.findAll", FixedInternet.class).getResultList();

		} catch (PersistenceException e) {
			throw new PhoneInternetException("Cannot load fixed internet services");
		}
		
		return fixedInternetList;
	}
	
	
	public List<FixedPhone> findAllFixedPhoneServices() throws PhoneInternetException{
		List<FixedPhone> fixedPhoneList = null;
		try {
			fixedPhoneList = em.createNamedQuery("FixedPhone.findAll", FixedPhone.class).getResultList();

		} catch (PersistenceException e) {
			throw new PhoneInternetException("Cannot load fixed phone services");
		}
		
		return fixedPhoneList;
	}
	
	
	public List<MobileInternet> findAllMobileInternetServices() throws PhoneInternetException{
		List<MobileInternet> mobileInternetList = null;
		try {
			mobileInternetList = em.createNamedQuery("MobileInternet.findAll", MobileInternet.class).getResultList();

		} catch (PersistenceException e) {
			throw new PhoneInternetException("Cannot load mobile internet services");
		}
		
		return mobileInternetList;
	}
	
	
	public List<MobilePhone> findAllMobilePhoneServices() throws PhoneInternetException{
		List<MobilePhone> mobilePhoneList = null;
		try {
			mobilePhoneList = em.createNamedQuery("MobilePhone.findAll", MobilePhone.class).getResultList();

		} catch (PersistenceException e) {
			throw new PhoneInternetException("Cannot load mobile phone services");
		}
		
		return mobilePhoneList;
	}
	
	
}
