package services;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import entities.OptionalProduct;
import entities.Order;
import entities.ServicePackage;
import entities.User;
import entities.ValidityPeriod;
import exceptions.OrderException;

@Stateless
public class OrderService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;
	@EJB(name = "services/ActivationScheduleService")
	private ActivationScheduleService asService;
	@EJB(name = "services/AuditingTableService")
	private AuditingTableService atService;
	@EJB(name = "services/OptionalProductService")
	private OptionalProductService opService;


	public OrderService() {
	}
	
	public List<Order> findRejectedOrders(User user) throws OrderException{
		List<Order> rejectedOrderList = null;

		if( user!=null && !user.isInsolvent())
			return rejectedOrderList;
		try {
			TypedQuery<Order> query = em.createNamedQuery("Order.findRejectedOrders", Order.class).setParameter("user", user);
			rejectedOrderList = query.getResultList();
		} catch (PersistenceException e) {
			throw new OrderException("Fail to retrieve rejected orders");
		}
		if( rejectedOrderList.isEmpty())
			rejectedOrderList = null;
		return rejectedOrderList;
	}
	
	
	public Order createOrder(User user, ServicePackage sp, List<OptionalProduct> opList, ValidityPeriod vp, Date startDate, float totAmount) throws OrderException {
		
		LocalDateTime now = LocalDateTime.now();
		Date creationDateTime = Timestamp.valueOf(now);
		Order order;
		
		
		if(!sp.getValidityPeriods().contains(vp)) 
			throw new OrderException("Validity period not valid for the selected service package");

		if(opList != null) {
			if(!sp.getOptionalProducts().containsAll(opList))
				throw new OrderException("Optional products not valid for the selected service package");
			
			order = new Order(totAmount, creationDateTime, startDate, user, sp, vp, opList);
		
		} else
			order = new Order(totAmount, creationDateTime, startDate, user, sp, vp);
		
		
		em.persist(order);
		
		return order;
	}
	
	// order processed for the first time
	public void processOrder(boolean successfulPayment, Order order, User user, ValidityPeriod vp) {
		
		Order ord = em.find(Order.class, order.getId());	//find() returns a managed object
		User usr = em.find(User.class, user.getId());
		boolean rejected = !successfulPayment;
		ord.setRejected(rejected);
		
	
		if(rejected) {
			
			ord.increaseNumFailedPayments(); //order - increases by one
			
			usr.setInsolvent(true);
			usr.increaseNumFailedPayments();		//user - increases by one
			if(usr.getNumFailedPayments() == 3)
				atService.createAuditingEntry(usr);
			else if(usr.getNumFailedPayments() >= 3)
				atService.updateAuditingEntry(usr, ord, false);	
		
		} else {
			if(usr.getNumFailedPayments() == 0)
				usr.setInsolvent(false);
			else
				usr.setInsolvent(true);
			
			//create an activation schedule
			asService.createActivationSchedule(ord.getStartDate(), vp.getNumMonths(), ord);
		}

	}
	
	
	public void reProcessOrder(boolean successfulPayment, Order order, User user, ValidityPeriod vp) {

		Order ord = em.find(Order.class, order.getId());	//find() returns a managed object
		User usr = em.find(User.class, user.getId());
		boolean rejected = !successfulPayment;
		ord.setRejected(rejected);
		
		if(rejected) {
	
			ord.increaseNumFailedPayments(); 	//order - increases by one
			
			usr.setInsolvent(true);
			usr.increaseNumFailedPayments();		//user - increases by one
			if(usr.getNumFailedPayments() == 3)
				atService.createAuditingEntry(usr);
			else if(usr.getNumFailedPayments() >= 3)
				atService.updateAuditingEntry(usr, ord, false);		
					
		} else {
			
			usr.decreaseNumFailedPayments(ord.getNumFailedPayments());		//decreases
			ord.setNumFailedPayments(0);
			
			if(usr.getNumFailedPayments() == 0)
				usr.setInsolvent(false);
			else
				usr.setInsolvent(true);
				
			
			if(usr.getNumFailedPayments() < 3)
				atService.deleteAlert(usr, ord);
			
			// if a pending order is confirmed and the alert is not deleted 
			//decrease the amount value in the alert
			else {
				atService.updateAuditingEntry(usr, ord, true);
			}
			
			/*List<Order> rejectedOrderList = null;
			try {
				rejectedOrderList = findRejectedOrders(usr);
			} catch (OrderException e) {
				e.printStackTrace();
			}
			
			if(rejectedOrderList == null) {
				usr.setInsolvent(false);
				usr.setNumFailedPayments(0);
			}*/
				
			//create an activation schedule
			asService.createActivationSchedule(ord.getStartDate(), vp.getNumMonths(), ord);
		}

		
	}
	
	
	public Order findOrderById(int idOrder) {
		Order order = em.find(Order.class, idOrder);
		return order;
	}
	
	
	public ValidityPeriod getValidityPeriodForOrder(Order order) {
		ValidityPeriod validityPeriod = order.getValidityPeriod();
		return validityPeriod;
	}
	
	public ServicePackage getServicePackageForOrder(Order order) {
		return order.getServicePackage();
	}
	
	public Date getStartDateForOrder(Order order) {
		return order.getStartDate();
	}
	
	public float getTotAmountForOrder(Order order) {
		return order.getTotAmount();
	}

	public List<OptionalProduct> getOptionalProductsForOrder(Order order) {
		return order.getOptionalProducts();
	}
	
	public float calculateTotExpenseForOrder(ValidityPeriod vp, List<OptionalProduct> optionalProductList) {
		 float totForOp = opService.calculateTotAmountForOptionalProductsSelected(optionalProductList);
		 float totAmount = ( vp.getMonthlyFee() + totForOp ) * vp.getNumMonths();	 
		 return totAmount;
	}

	

	

}
