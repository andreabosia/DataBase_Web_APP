package services;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.ValidityPeriod;
import exceptions.ValidityPeriodException;

@Stateless
public class ValidityPeriodService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public ValidityPeriodService() {
	}

	
	public ValidityPeriod findValidityPeriodById(int servicePackageId) {
		ValidityPeriod vp = em.find(ValidityPeriod.class, servicePackageId);
		return vp;
	}
	
	
	public List<ValidityPeriod> findAllValidityPeriods() throws ValidityPeriodException {
		List<ValidityPeriod> validityPeriodList = null;
		try {
			validityPeriodList = em.createNamedQuery("ValidityPeriod.findAll", ValidityPeriod.class).getResultList();

		} catch (PersistenceException e) {
			throw new ValidityPeriodException("Cannot load validity periods");
		}
		return validityPeriodList;
	}

}
