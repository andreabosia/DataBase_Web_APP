package services;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.AuditingTable;
import entities.Order;
import entities.User;
import exceptions.OrderException;



@Stateless
public class AuditingTableService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;
	@EJB(name = "services/OrderService")
	private OrderService ordService;


	public AuditingTableService() {
	}
	
	
	public AuditingTable findAuditingTableByUserName(User user) {
		
		String username = user.getUsername();
		 List<AuditingTable> auditingTableList =  em.createQuery("Select at from AuditingTable at where at.user.username = :username ", AuditingTable.class)
				.setParameter("username", username).getResultList();
		 AuditingTable auditingTable = null;
		 if(auditingTableList.size() != 0)
			 auditingTable = auditingTableList.get(0);
		 
		 return auditingTable;

	}
	
	
	public void createAuditingEntry(User user) {
		
		// date and time of last rejection
		LocalDateTime now = LocalDateTime.now(); 
		Date rejectionDate = java.sql.Timestamp.valueOf(now); 
		
		// amount = sum of all the rejected orders
		float amount = 0;
		List<Order> rejectedOrd = null;
		
		try {
			rejectedOrd = ordService.findRejectedOrders(user);
		} catch (OrderException e) {
			e.printStackTrace();
		}
		
		if(rejectedOrd != null) {
			for (Order o: rejectedOrd)
				amount = amount + o.getTotAmount();
		}
		
		AuditingTable auditingTable = new AuditingTable(amount, rejectionDate, user);
		
		em.persist(auditingTable);

	}
	
	
	public void updateAuditingEntry(User user, Order order, boolean decrease) {
		
		AuditingTable atToUpdate = findAuditingTableByUserName(user); //query returns a managed object
		float oldAmount = atToUpdate.getAmount();
		float newAmount = 0;
		
		if(!decrease) {
			
			// date and time of last rejection
			LocalDateTime now = LocalDateTime.now(); 
			Date rejectionDate = java.sql.Timestamp.valueOf(now);
			atToUpdate.setRejectionDateTime(rejectionDate);
			
			List<Order> rejectedOrd = null;
			float amount = 0;
			
			try {
				rejectedOrd = ordService.findRejectedOrders(user);
			} catch (OrderException e) {
				e.printStackTrace();
			}
			
			if(rejectedOrd != null) {
				for (Order o: rejectedOrd)
					amount = amount + o.getTotAmount();
			}
			
			newAmount = amount;		//increase
		
			
		} else {
			
			newAmount = oldAmount - order.getTotAmount();	//decrease
		}
		
		
		atToUpdate.setAmount(newAmount);
		
	}
	
	
	public void deleteAlert(User user, Order order) {

		AuditingTable atToDelete = findAuditingTableByUserName(user);

		if(atToDelete != null)
			em.remove(atToDelete);
	}
	

}