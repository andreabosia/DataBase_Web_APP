package services;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import entities.OptionalProduct;
import exceptions.OptionalProductException;

@Stateless
public class OptionalProductService {
	@PersistenceContext(unitName = "TelcoAppEJB")
	private EntityManager em;

	public OptionalProductService() {
	}

	
	public OptionalProduct findOptionalProductById(int optionalProductId) {
		OptionalProduct vp = em.find(OptionalProduct.class, optionalProductId);
		return vp;
	}

	
	public List<OptionalProduct> createListOfSelectedOptionalProducts(List<String> optionalProductsId) {

		List<OptionalProduct> optionalProductList = new ArrayList<OptionalProduct>();
		int opId;
		for (String tmp : optionalProductsId) {
			opId = Integer.parseInt(tmp);
			optionalProductList.add(findOptionalProductById(opId));
		}
		return optionalProductList;
	}

	
	public float calculateTotAmountForOptionalProductsSelected(List<OptionalProduct> optionalProductList) {

		float totForOp = 0;

		if (optionalProductList == null)
			return totForOp;

		for (OptionalProduct op : optionalProductList)
			totForOp = op.getMonthlyFee() + totForOp;

		return totForOp;
	}

	
	public List<OptionalProduct> findAllOptionalProducts() throws OptionalProductException {
		List<OptionalProduct> optionalProductList = null;
		try {
			optionalProductList = em.createNamedQuery("OptionalProduct.findAll", OptionalProduct.class).getResultList();

		} catch (PersistenceException e) {
			throw new OptionalProductException("Cannot load optional products");
		}

		return optionalProductList;
	}

	
	public void createOptionalProduct(String name, float monthlyFee) throws OptionalProductException {

		// check that the name is unique
		List<OptionalProduct> duplicates = em.createNamedQuery("OptionalProduct.findByName", OptionalProduct.class)
				.setParameter("name", name).getResultList();
		if (!duplicates.isEmpty())
			throw new OptionalProductException("The specified name has already been used");

		// create a new optional product
		OptionalProduct op = new OptionalProduct(name, monthlyFee);

		// persist into the db
		try {
			em.persist(op);
		} catch (PersistenceException e) {
			throw new PersistenceException(
					"An error has occurred during the optional product creation, please retry later");
		}

	}


}
