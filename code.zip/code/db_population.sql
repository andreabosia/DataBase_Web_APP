use db_telco;

/*select * from validity_period;
select * from user_table;
select * from service_package;
select * from orders;
select * from employee;
select * from optional_product;

select * from service_package_optional_product;
select * from service_package_validity_period;

select * from fixed_phone;
select * from mobile_phone;
select * from fixed_internet;
select * from mobile_internet;

select * from activation_schedule;*/


insert into employee(id,username,password) values
(1,"admin1","admin1"),
(2,"admin2","admin2");

insert into user_table(id,username,password,is_insolvent,email,num_failed_payments) values
(1,'erika','erika',default,'e.b@polimi.it',default),
(2,'andrea','andrea',default,'a.b@polimi.it',default);

insert into fixed_phone(id,name) values 
(1,"Fixed phone 1"),
(2,"Fixed phone 2"),
(3,"Fixed phone 3");

insert into mobile_phone(id,name,num_minutes,num_sms,extra_min_fee,extra_sms_fee) values 
(1,"Mobile phone 1",1000,500,0.10,0.15),
(2,"Mobile phone 2",800,400,0.10,0.15),
(3,"Mobile phone 3",500,100,0.10,0.15);

insert into fixed_internet(id,name,num_giga,extra_giga_fee) values 
(1,"Fixed internet 1",100,1.0),
(2,"Fixed internet 2",200,1.0),
(3,"Fixed internet 3",300,1.0);

insert into mobile_internet(id,name,num_giga,extra_giga_fee) values 
(1,"Mobile internet 1",100,1.0),
(2,"Mobile internet 2",50,1.0),
(3,"Mobile internet 3",10,1.0);

insert into optional_product(id,name,monthly_fee) values 
(1,"optional product 1",1.0),
(2,"optional product 2",1.5),
(3,"optional product 3",2.0),
(4,"optional product 4",3.0);

insert into validity_period(id,num_months,monthly_fee) values
(1,3,18),
(2,6,15),
(3,9,12),
(4,12,10);

insert into service_package(id,id_fixedphone,id_mobilephone,id_fixedinternet,id_mobileinternet,name) values
(1, null, 3, 1, 3, "Basic"),
(2, 1, 2, 3, 1, "Family"),
(3, 2, 3, 3, 2, "Business"),
(4, 3, 2, 2, 2, "All Inclusive");

insert into service_package_optional_product(id_servicepackage,id_optionalproduct) values
(1,1),
(1,2),
(1,3),
(2,1),
(2,3),
(3,4);

insert into service_package_validity_period(id_servicepackage,id_validityperiod) values
(1,1),
(1,2),
(1,3),
(2,3),
(2,4),
(3,2),
(3,3),
(3,4),
(4,4);

