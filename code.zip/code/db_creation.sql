use db_telco;

drop table if exists employee;
drop table if exists service_package_validity_period;
drop table if exists service_package_optional_product;
drop table if exists order_optional_product;
drop table if exists optional_product;
drop table if exists auditing_table;
drop table if exists activation_schedule;
drop table if exists orders;
drop table if exists user_table;
drop table if exists service_package;
drop table if exists validity_period;
drop table if exists fixed_phone;
drop table if exists mobile_phone;
drop table if exists fixed_internet;
drop table if exists mobile_internet;

create table employee (
	id int not null auto_increment,
	username varchar(45) not null unique,
	password varchar(45) not null,
	primary key (id)
);

create table user_table (
	id int not null auto_increment,
	username varchar(45) not null unique,
	password varchar(45) not null,
	is_insolvent boolean not null default false,
	email varchar(45) not null unique,
	num_failed_payments int not null default 0,
    unique (id,username,email),
	primary key (id)
);

create table auditing_table (
	id int not null auto_increment,
	id_user int not null,
	username varchar(45) not null,
	email varchar(45) not null,
	amount decimal(5,2) not null,
	rejection_date_time datetime not null,
    foreign key (id_user,username,email) references user_table(id,username,email) on update cascade on delete cascade,
	primary key (id)
);

create table fixed_phone (
	id int not null auto_increment,
	name varchar(45) not null unique,
	primary key (id)
);
 
create table mobile_phone (
	id int not null auto_increment,
	name varchar(45) not null unique,
	num_minutes int not null,
	num_sms int not null,
	extra_min_fee decimal(5,2) not null,
	extra_sms_fee decimal(5,2) not null,
	primary key (id)
);

create table fixed_internet (
	id int not null auto_increment,
	name varchar(45) not null unique,
	num_giga int not null,
	extra_giga_fee decimal(5,2) not null,
	primary key (id)
);
 
create table mobile_internet (
	id int not null auto_increment,
	name varchar(45) not null unique,
	num_giga int not null,
	extra_giga_fee decimal(5,2) not null,
	primary key (id)
);

create table service_package(
	id int not null auto_increment,
	id_fixedphone int,
	id_mobilephone int,
	id_fixedinternet int,
	id_mobileinternet int,
	name varchar(45) not null unique,
    foreign key (id_fixedphone) references fixed_phone(id) on update cascade on delete restrict,
    foreign key (id_mobilephone) references mobile_phone(id) on update cascade on delete restrict,
    foreign key (id_fixedinternet) references fixed_internet(id) on update cascade on delete restrict,
    foreign key (id_mobileinternet) references mobile_internet(id) on update cascade on delete restrict,
	primary key (id)
);

create table validity_period (
	id int not null auto_increment,
	num_months int not null,
	monthly_fee decimal(5,2) not null,
    unique (num_months, monthly_fee),
    check(num_months > 0),
    check(monthly_fee >= 0),
	primary key (id)
);

create table service_package_validity_period (
	id_servicepackage int not null,
	id_validityperiod int not null,
    foreign key (id_servicepackage) references service_package(id) on update cascade on delete cascade,
    foreign key (id_validityperiod) references validity_period(id) on update cascade on delete cascade,
	primary key (id_servicepackage, id_validityperiod)
);

create table orders (
	id int not null auto_increment,
	id_servicepackage int not null,
	id_user int not null,
	id_validityperiod int not null,
	tot_amount decimal(5,2) not null,
	rejected boolean default null,
	start_date date not null,
	creation_date_time timestamp not null,
    num_failed_payments int not null default 0,
    foreign key (id_servicepackage) references service_package(id) on update cascade on delete restrict,
    foreign key (id_user) references user_table(id) on update cascade on delete restrict,
    foreign key (id_validityperiod) references validity_period(id) on update cascade on delete restrict,
	primary key (id)
);

create table activation_schedule (
	id int not null auto_increment,
	activation_date date not null,
	deactivation_date date not null,
    id_order int not null,
    foreign key (id_order) references orders(id) on update cascade on delete cascade, 
	primary key (id)
);
 
create table optional_product (
	id int not null auto_increment,
	name varchar(45) not null unique,
	monthly_fee decimal(5,2) not null,
    check(monthly_fee >= 0),
	primary key (id)
);
 
create table service_package_optional_product (
	id_servicepackage int not null,
	id_optionalproduct int not null,
    foreign key (id_servicepackage) references service_package(id) on update cascade on delete cascade,
    foreign key (id_optionalproduct) references optional_product(id) on update cascade on delete cascade,
	primary key (id_servicepackage, id_optionalproduct)
);

create table order_optional_product (
	id_order int not null,
	id_optionalproduct int not null,
    foreign key (id_order) references orders (id) on update cascade on delete cascade,
    foreign key (id_optionalproduct) references optional_product(id) on update cascade on delete cascade,
	primary key (id_order, id_optionalproduct)
);
