package controllers;

import java.io.IOException;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.ServicePackage;
import exceptions.ServicePackageException;
import services.OrderService;
import services.ServicePackageService;


//
// 	This controller is called upon a service package selection in the BuyServicePage.html
// 	The variable that identify the selected service package is sent to the controller in the request and saved in the session object
//	The controller retrieves the needed info about the service package (calling services of the business logic)
// 	The info retrieved are then saved in the session ??
//	Test: don't save in the session and don't redirect, just simply call template...
//

@WebServlet("/OnServicePackageSelection")
public class OnServicePackageSelection extends HttpServlet {


	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/ServicePackageService")
	private ServicePackageService spService;
	@EJB(name = "services/OrderService")
	private OrderService ordService;

	public OnServicePackageSelection() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());

		//get selected service package from the request
		try {
			int servicePackageId = Integer.parseInt((String) request.getParameter("servicePackageId"));
			ctx.setVariable("servicePackageId", servicePackageId);
			
		} catch (NumberFormatException e) {
			response.sendError(500, "Invalid productId");
		}

		
		//if no service package has been selected redirect 
		if (ctx.getVariable("servicePackageId") == null) {
		
			String ctxpath = getServletContext().getContextPath();
			String path = ctxpath + "/BuyServicePage";
			response.sendRedirect(path);
					
		} else {
			int servicePackageId = (int) ctx.getVariable("servicePackageId");
		
			//call service to retrieve correct servicePackage
			ServicePackage sp = spService.findServicePackageById(servicePackageId);
			
			// retrieve all the service packages
			List<ServicePackage> packageList = null;
			try {
				packageList = spService.findAllServicePackages();
				
			} catch (ServicePackageException e) {
				response.sendError(500, e.getMessage());
				return;
			}
			
			
			ctx.setVariable("sp",sp);
			ctx.setVariable("packageList", packageList);
			templateEngine.process("/WEB-INF/BuyServicePage.html", ctx, response.getWriter());
	
		}
	}
	
	
	public void destroy() {
	}

}