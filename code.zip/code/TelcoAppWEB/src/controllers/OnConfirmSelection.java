package controllers;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;


@WebServlet("/OnConfirmSelection")
public class OnConfirmSelection extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		HttpSession session = request.getSession(false);
		
		if(session == null) {
			response.sendError(403, "Access denied");
			return;
		}

			//GET request from ConfirmationPage.html - user not logged in
		if(session.getAttribute("user") == null) {
			templateEngine.process("/WEB-INF/LogInSignIn.html", ctx, response.getWriter());
			return;
			
			
			// GET request from ConfirmationPage.html - attempt an old payment
		} else if (session.getAttribute("user") != null && session.getAttribute("attemptPayment") != null) {
			String ctxpath = getServletContext().getContextPath();
			String path = ctxpath + "/AttemptPayment";
			response.sendRedirect(path);
			
			
			//GET request from ConfirmationPage.html - create a new order
		} else if (session.getAttribute("user") != null && session.getAttribute("servicePackage") != null) {
			String ctxpath = getServletContext().getContextPath();
			String path = ctxpath + "/CreateOrder";
			response.sendRedirect(path);


		} else if (session.getAttribute("user") != null && session.getAttribute("servicePackage") == null 
				&& session.getAttribute("attemptPayment") == null) {
			String ctxpath = getServletContext().getContextPath();
			String path = ctxpath + "/Home";
			response.sendRedirect(path);
		}
			
	}

}
