package controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.persistence.PersistenceException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;

import exceptions.OptionalProductException;
import services.OptionalProductService;

@WebServlet("/CreateOptionalProduct")
public class CreateOptionalProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB(name = "services/OptionalProductService")
	private OptionalProductService opService;

	public CreateOptionalProduct() {
		super();
	}

	public void init() throws ServletException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the employee is not logged in (not present in session) redirect to the login
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("auth") == null) {
			String loginpath = getServletContext().getContextPath() + "/employeeLogin.html";
			response.sendRedirect(loginpath);
			return;
		}
		
		// get name
		String opProductName = StringEscapeUtils.escapeJava(request.getParameter("opProductName"));
		if(opProductName == null || opProductName == "") {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing product name");
			return;
		}
		
		// get monthly fee
		String opProductMonthlyFee = StringEscapeUtils.escapeJava(request.getParameter("opProductMonthlyFee"));
		if(opProductMonthlyFee == null || opProductMonthlyFee == "") {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing monthly fee");
			return;
		}
		
		float monthlyFee = 0;
		try {
			monthlyFee = Float.parseFloat(opProductMonthlyFee);
			if(monthlyFee < 0) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Monthly fee must be positive");
				return;
			}
				
		} catch(NumberFormatException | NullPointerException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
			return;
		}
		
		
		// create optional product in the db
		try {
			opService.createOptionalProduct(opProductName, monthlyFee);
		} catch(OptionalProductException e1) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e1.getMessage());
			return;
		} catch (PersistenceException e2) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e2.getMessage());
			return;
		}
		
		
		// redirect to the home page
		//String path = getServletContext().getContextPath() + "/EmployeeHome";
		//response.sendRedirect(path);
		
		request.setAttribute("createproductMsg", "Optional product created successfully!");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeHome");
		dispatcher.forward(request, response);
		
	}
	
	
	public void destroy() {
	}
}
