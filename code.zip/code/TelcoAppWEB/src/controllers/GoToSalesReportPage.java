package controllers;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.AuditingTable;
import entities.Order;
import entities.User;
import exceptions.SalesReportException;
import materializedviews.AvgOptionalProduct;
import materializedviews.BestSeller;
import materializedviews.TotPurchasesPackage;
import materializedviews.TotPurchasesPackageVPeriod;
import materializedviews.TotSalesPackage;
import services.SalesReportService;

@WebServlet("/SalesReport")
public class GoToSalesReportPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/SalesReportService")
	private SalesReportService srService;

	public GoToSalesReportPage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the employee is not logged in (not present in session) redirect to the login
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("auth") == null) {
			String loginpath = getServletContext().getContextPath() + "/employeeLogin.html";
			response.sendRedirect(loginpath);
			return;
		}

		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());

		// load number of purchases per package
		List<TotPurchasesPackage> purchasesList = null;
		try {
			purchasesList = srService.findAllPurchasesPackage();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// load number of purchases per package and validity period
		List<TotPurchasesPackageVPeriod> purchasesList2 = null;
		try {
			purchasesList2 = srService.findAllPurchasesPackageVPeriod();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// total value of sales per package with and without the optional products
		List<TotSalesPackage> salesList = null;
		try {
			salesList = srService.findAllSalesPackage();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// average number of optional products sold together with each service package
		List<AvgOptionalProduct> opProductsList = null;
		try {
			opProductsList = srService.findAllAvgOpProduct();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// list of insolvent users
		List<User> insolventList = null;
		try {
			insolventList = srService.findAllInsolventUsers();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// list of suspended orders
		List<Order> rejectedList = null;
		try {
			rejectedList = srService.findAllRejectedOrders();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		// list of alerts
		List<AuditingTable> alertList = null;
		try {
			alertList = srService.findAllAlerts();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}
		
		// best seller optional product
		BestSeller bestSeller = null;
		try {
			bestSeller = srService.findBestSeller();
		} catch (SalesReportException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not possible to get data");
			return;
		}

		ctx.setVariable("purchasesList", purchasesList);
		ctx.setVariable("purchasesList2", purchasesList2);
		ctx.setVariable("salesList", salesList);
		ctx.setVariable("opProductsList", opProductsList);
		ctx.setVariable("insolventList", insolventList);
		ctx.setVariable("rejectedList", rejectedList);
		ctx.setVariable("alertList", alertList);
		ctx.setVariable("bestSeller", bestSeller);
		
		templateEngine.process("/WEB-INF/SalesReportPage.html", ctx, response.getWriter());

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public void destroy() {
	}

}
