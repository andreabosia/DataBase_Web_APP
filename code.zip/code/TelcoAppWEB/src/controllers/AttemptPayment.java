package controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.Order;
import entities.ValidityPeriod;
import external.service.BillingAutomation;
import entities.User;
import services.OrderService;
import services.UserService;

@WebServlet("/AttemptPayment")
public class AttemptPayment extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/OrderService")
	private OrderService oService;
	@EJB(name = "services/UserService")
	private UserService usrService;
	

	public AttemptPayment() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());

		BillingAutomation ba =  new BillingAutomation();
		boolean successfulPayment = ba.attemptPayment((boolean) session.getAttribute("makePaymentFail"));
		ctx.setVariable("successfulPayment", successfulPayment);
		
		User user = (User)session.getAttribute("user");
		
		Order order = oService.findOrderById((int) session.getAttribute("order"));
		ValidityPeriod validityPeriod = oService.getValidityPeriodForOrder(order);
		oService.reProcessOrder(successfulPayment, order, user, validityPeriod);

		
		// clean session parameters
		session.removeAttribute("optionalProductList");	
		session.removeAttribute("servicePackage");	
		session.removeAttribute("startDate");	
		session.removeAttribute("validityPeriod");	
		session.removeAttribute("totAmount");	
		session.removeAttribute("makePaymentFail");
		session.removeAttribute("order");
		session.removeAttribute("attemptPayment");
		
		templateEngine.process("/WEB-INF/CompletePayment.html", ctx, response.getWriter());
		
	}
	

	public void destroy() {
	}
	
}
