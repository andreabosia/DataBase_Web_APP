package controllers;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.OptionalProduct;
import entities.Order;
import entities.ServicePackage;
import entities.ValidityPeriod;
import exceptions.OrderException;
import services.OptionalProductService;
import services.OrderService;
import services.ServicePackageService;
import services.ValidityPeriodService;

@WebServlet("/GoToConfirmationPage")
public class GoToConfirmationPage extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/ServicePackageService")
	private ServicePackageService spService;
	@EJB(name = "services/ValidityPeriodService")
	private ValidityPeriodService vpService;
	@EJB(name = "services/OptionalProductService")
	private OptionalProductService opService;
	@EJB(name = "services/OrderService")
	private OrderService oService;


	public GoToConfirmationPage() {
		super();
	}

	private Date getYesterday() {
		return new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
	}
	
	
	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		HttpSession session = request.getSession(false);
		
		if (session == null) {
			response.sendError(403, "Access denied");
			return;
		}
		
		
		// GET request from CheckLogin.java
		// user logged in and new order saved in session - show order details before completing the purchase
		if (session.getAttribute("user") != null && session.getAttribute("servicePackage") != null) {
			templateEngine.process("/WEB-INF/ConfirmationPage.html", ctx, response.getWriter());
			return;
		}
		
		// GET request from Home.html 
		// user logged in and attempt payment 
		if(session.getAttribute("user") != null && request.getParameter("orderid") != null) {
			
			// get all info about the order
			Integer orderId = Integer.parseInt(request.getParameter("orderid"));
			Order order = oService.findOrderById(orderId);
			ServicePackage servicePackage = oService.getServicePackageForOrder(order);
			ValidityPeriod validityPeriod = oService.getValidityPeriodForOrder(order);
			Date startDate = oService.getStartDateForOrder(order);
			float totAmount = oService.getTotAmountForOrder(order);
			List<OptionalProduct> optionalProductList = oService.getOptionalProductsForOrder(order);
			
			// save info in the session
			if( optionalProductList != null)
				session.setAttribute("optionalProductList", optionalProductList);
			session.setAttribute("servicePackage", servicePackage);
			session.setAttribute("startDate", startDate);
			session.setAttribute("validityPeriod", validityPeriod);
			session.setAttribute("totAmount", totAmount);
			
			session.setAttribute("order", orderId);
			session.setAttribute("attemptPayment", true);	//to distinguish the attempts of payment
			
			boolean makePaymentFail = false;
			if(request.getParameter("makePaymentFail") != null && request.getParameter("makePaymentFail").equals("true"))
				 makePaymentFail = true;
			
			session.setAttribute("makePaymentFail", makePaymentFail);

			templateEngine.process("/WEB-INF/ConfirmationPage.html", ctx, response.getWriter());
			return;
		
		
		} else if (session.getAttribute("user") != null && session.getAttribute("servicePackage") == null 
				&& request.getParameter("orderid") == null) {
			String ctxpath = getServletContext().getContextPath();
			String path = ctxpath + "/Home";
			response.sendRedirect(path);
		}
		
		
	}

	
	
		//POST request from BuyServicePage.html
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		HttpSession session = request.getSession();

		try {
				
			boolean makePaymentFail = false;
			if(request.getParameter("makePaymentFail") != null && request.getParameter("makePaymentFail").equals("true"))
				 makePaymentFail = true;
			
			//retrieving all the info from the request
			int servicePackageId = Integer.parseInt(request.getParameter("sp.id"));
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date startDate = (Date) sdf.parse(request.getParameter("date"));
			if(getYesterday().after(startDate)) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "The start date cannot be in the past");
				return;
			}
			
			int validityPeriodId = Integer.parseInt(request.getParameter("vp.id"));
			
			String[] optionalProducts = request.getParameterValues("optionalProducts");	
			List<OptionalProduct> optionalProductList = null;
			//if an optional product has been selected 
			if(optionalProducts != null) {			//check that it is a valid optional product
				List<String> optionalProductsId = Arrays.asList(optionalProducts);
				optionalProductList = opService.createListOfSelectedOptionalProducts(optionalProductsId);
			}
			
			if (servicePackageId <= 0 || startDate == null || validityPeriodId <= 0) {
				throw new OrderException("Missing or invalid values for order");
			}
			
			
			ServicePackage servicePackage = spService.findServicePackageById(servicePackageId);		//try catch
			ValidityPeriod validityPeriod = vpService.findValidityPeriodById(validityPeriodId);		//try catch
			float totAmount = oService.calculateTotExpenseForOrder(validityPeriod, optionalProductList);		//try catch


			//save all the parameters of the incoming order in the session
			if( optionalProductList != null)
				session.setAttribute("optionalProductList", optionalProductList);
			session.setAttribute("servicePackage", servicePackage);
			session.setAttribute("startDate", startDate);
			session.setAttribute("validityPeriod", validityPeriod);
			session.setAttribute("totAmount", totAmount);
			session.setAttribute("makePaymentFail", makePaymentFail);
			
		} catch (NumberFormatException | ParseException  | OrderException e ) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
			return;
		}

		templateEngine.process("/WEB-INF/ConfirmationPage.html", ctx, response.getWriter());

	}
	
	
	public void destroy() {
	}

}