package controllers;


import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;


import entities.ServicePackage;
import exceptions.*;
import services.ServicePackageService;

//
//	This controller is invoked from Home.html 
//	It only loads from the db all the available service packages, saves them in the ctx and renders the page GoToBuyServicePage.html
//	test: decide if the onServicePackageSelection redirect to this controller (saving info in session)
//
@WebServlet("/BuyServicePage")
public class GoToBuyServicePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/ServicePackageService")
	private ServicePackageService spService;

	public GoToBuyServicePage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	//	doGet method is called from Home.html and retrieves info to fill the page
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());

		List<ServicePackage> packageList = null;
		try {
			packageList = spService.findAllServicePackages();
			
		} catch (ServicePackageException e) {
			response.sendError(500, e.getMessage());
			return;
		}
		
		//save in the context, no need to save in the session if every time is reloaded
		ctx.setVariable("packageList", packageList);
		templateEngine.process("/WEB-INF/BuyServicePage.html", ctx, response.getWriter());
		
	}
	

	public void destroy() {
	}

}
