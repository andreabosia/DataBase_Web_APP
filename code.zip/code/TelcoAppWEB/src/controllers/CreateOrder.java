package controllers;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.OptionalProduct;
import entities.Order;
import entities.ServicePackage;
import entities.ValidityPeriod;
import exceptions.OrderException;
import external.service.BillingAutomation;
import entities.User;
import services.OrderService;


@WebServlet("/CreateOrder")
public class CreateOrder extends HttpServlet {


	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/OrderService")
	private OrderService oService;
	

	public CreateOrder() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		HttpSession session = request.getSession(false);
		

		try {
			
			// get all variables sent from BuyServicePage.html and saved in the session
			User user = (User)session.getAttribute("user");
			ServicePackage servicePackage = (ServicePackage) session.getAttribute("servicePackage");
			@SuppressWarnings("unchecked")
			List<OptionalProduct> oPList = (List<OptionalProduct>)session.getAttribute("optionalProductList");
			ValidityPeriod validityPeriod = (ValidityPeriod) session.getAttribute("validityPeriod");
			Date startDate = (Date) session.getAttribute("startDate");
			float totAmount = (float) session.getAttribute("totAmount");
			
			
			// create a new order
			Order order;
			try {
				order = oService.createOrder(user, servicePackage, oPList, validityPeriod, startDate, totAmount);
			} catch (OrderException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
				return;
			}
			

			// process the payment
			BillingAutomation ba =  new BillingAutomation();
			boolean successfulPayment = ba.attemptPayment((boolean)session.getAttribute("makePaymentFail"));
			
			
			ctx.setVariable("successfulPayment", successfulPayment);
			User usr = (User)session.getAttribute("user");
			oService.processOrder(successfulPayment, order, usr, validityPeriod);
			
	
		} catch (NumberFormatException e ) {
			response.sendError(500, "Missing session variables or failed to create order");
			return;
		}

		
		// after creating the order all the session parameters must be cleaned 
		session.removeAttribute("optionalProductList");	
		session.removeAttribute("servicePackage");	
		session.removeAttribute("startDate");	
		session.removeAttribute("validityPeriod");	
		session.removeAttribute("totAmount");	
		session.removeAttribute("makePaymentFail");
		
		templateEngine.process("/WEB-INF/CompletePayment.html", ctx, response.getWriter());
		
	}
	

	public void destroy() {
	}
	
}
