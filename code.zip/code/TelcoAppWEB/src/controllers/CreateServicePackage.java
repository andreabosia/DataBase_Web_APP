package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.persistence.PersistenceException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;

import exceptions.ServicePackageException;
import services.ServicePackageService;


@WebServlet("/CreateServicePackage")
public class CreateServicePackage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB(name = "services/ServicePackageService")
	private ServicePackageService spService;
	
	public CreateServicePackage() {
		super();
	}

	public void init() throws ServletException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the employee is not logged in (not present in session) redirect to the login
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("auth") == null) {
			String loginpath = getServletContext().getContextPath() + "/employeeLogin.html";
			response.sendRedirect(loginpath);
			return;
		}

		
		//get name
		String packageName = StringEscapeUtils.escapeJava(request.getParameter("packageName"));
		if(packageName == null || packageName == "") {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing package name");
			return;
		}
		
		
		// get services
		Integer fixedPhoneId;
		Integer mobilePhoneId;
		Integer fixedInternetId;
		Integer mobileInternetId;
		try {
			fixedPhoneId = Integer.parseInt(request.getParameter("fixedPhoneId"));
			mobilePhoneId = Integer.parseInt(request.getParameter("mobilePhoneId"));
			fixedInternetId = Integer.parseInt(request.getParameter("fixedInternetId"));
			mobileInternetId = Integer.parseInt(request.getParameter("mobileInternetId"));
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
			return;
		}
		
		
		// get validity periods from checkbox
		String[] checkedVp = null;
		List<Integer> vpIdList = new ArrayList<Integer>();
		try {
			if(request.getParameterValues("validityPeriod") !=  null) {
				checkedVp = request.getParameterValues("validityPeriod");
				for(String s: checkedVp) 
					vpIdList.add(Integer.parseInt(s));
			}
		} catch(NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
			return;
		}
		
		
		// get optional products from checkbox
		String[] checkedOp = null;
		List<Integer> opIdList = new ArrayList<Integer>();
		try {
			if(request.getParameterValues("optionalProduct") != null) {
				checkedOp = request.getParameterValues("optionalProduct");
				for(String s: checkedOp) 
					opIdList.add(Integer.parseInt(s));
			}	
		} catch(NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
			return;
		}
		
		
		// create service package in the db
		try {
			spService.createServicePackage(packageName, fixedPhoneId, mobilePhoneId, fixedInternetId, mobileInternetId, vpIdList, opIdList);
		} catch (ServicePackageException e1) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, e1.getMessage());
			return;
		} catch (PersistenceException e2) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e2.getMessage());
			return;
		}
		
		
		// redirect to the home page
		//String path = getServletContext().getContextPath() + "/EmployeeHome";
		//response.sendRedirect(path);
		
		request.setAttribute("createpackageMsg", "Service package created successfully!");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeHome");
		dispatcher.forward(request, response);

	}
	
	public void destroy() {
	}
	
}
