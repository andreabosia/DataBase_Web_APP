package controllers;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.Order;
import entities.ServicePackage;
import entities.User;
import exceptions.*;
import services.OrderService;
import services.ServicePackageService;
import services.UserService;


@WebServlet("/Home")
public class GoToHomePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/ServicePackageService")
	private ServicePackageService spService;
	@EJB(name = "services/OrderService")
	private OrderService ordService;
	@EJB(name = "services/UserService")
	private UserService usrService;

	public GoToHomePage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		
		
		if(request.getSession(false)!=null  &&  request.getSession(false).getAttribute("user")!=null) {
			//update of object user to make sure is the current one
			User user = usrService.findUserById((User) request.getSession().getAttribute("user"));
			request.getSession(false).setAttribute("user", user);
		
		
			List<Order> rejectedOrderList = null; 
			try {
				rejectedOrderList = ordService.findRejectedOrders(user);
				} catch (OrderException e) {
					ctx.setVariable("rejectedOrderErrorMsg", e.getMessage());
					return;
				}
				
			request.getSession(false).setAttribute("rejectedOrderList", rejectedOrderList);
		}
		
		
		List<ServicePackage> packageList = null;
		try {
			packageList = spService.findAllServicePackages();
		} catch (ServicePackageException e) {
			ctx.setVariable("servicePackageErrorMsg", e.getMessage());
			return;
		}

		ctx.setVariable("packageList", packageList);
		templateEngine.process("/WEB-INF/Home.html", ctx, response.getWriter());
	}


	
	public void destroy() {
	}

}
