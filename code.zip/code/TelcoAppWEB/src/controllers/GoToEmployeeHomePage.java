package controllers;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import entities.FixedInternet;
import entities.FixedPhone;
import entities.MobileInternet;
import entities.MobilePhone;
import entities.OptionalProduct;
import entities.ValidityPeriod;
import exceptions.OptionalProductException;
import exceptions.PhoneInternetException;
import exceptions.ValidityPeriodException;
import services.OptionalProductService;
import services.PhoneInternetService;
import services.ValidityPeriodService;

@WebServlet("/EmployeeHome")
public class GoToEmployeeHomePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/PhoneInternetService")
	private PhoneInternetService piService;
	@EJB(name = "services/ValidityPeriodService")
	private ValidityPeriodService vpService;
	@EJB(name = "services/OptionalProductService")
	private OptionalProductService opService;

	public GoToEmployeeHomePage() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// If the employee is not logged in (not present in session) redirect to the login
		HttpSession session = request.getSession();
		if (session.isNew() || session.getAttribute("auth") == null) {
			String loginpath = getServletContext().getContextPath() + "/employeeLogin.html";
			response.sendRedirect(loginpath);
			return;
		} 
		
		final WebContext ctx = new WebContext(request, response, this.getServletContext(), request.getLocale());
		
		// load services from db
		List<FixedInternet> fixedInternetList = null;
		List<FixedPhone> fixedPhoneList = null;
		List<MobileInternet> mobileInternetList = null;
		List<MobilePhone> mobilePhoneList = null;
		
		try {
			fixedInternetList = piService.findAllFixedInternetServices();
			fixedPhoneList = piService.findAllFixedPhoneServices();
			mobileInternetList = piService.findAllMobileInternetServices();
			mobilePhoneList = piService.findAllMobilePhoneServices();
		} catch (PhoneInternetException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			return;
		}
		
		// load validity periods from db
		List<ValidityPeriod> validityPeriodList = null;
		try {
			validityPeriodList = vpService.findAllValidityPeriods();
		} catch (ValidityPeriodException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			return;
		}
		
		// load optional products from db
		List<OptionalProduct> optionalProductList = null;
		try {
			optionalProductList = opService.findAllOptionalProducts();
		} catch (OptionalProductException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			return;
		}
		
		ctx.setVariable("fixedInternetList", fixedInternetList);
		ctx.setVariable("fixedPhoneList", fixedPhoneList);
		ctx.setVariable("mobileInternetList", mobileInternetList);
		ctx.setVariable("mobilePhoneList", mobilePhoneList);
		ctx.setVariable("validityPeriodList", validityPeriodList);
		ctx.setVariable("optionalProductList", optionalProductList);
		
		
		//request coming from CreateServicePackage servlet
		if(request.getAttribute("createpackageMsg") != null)
			ctx.setVariable("createpackageMsg", request.getAttribute("createpackageMsg"));
		
		//request coming from CreateOptionalProduct servlet
		if(request.getAttribute("createproductMsg") != null)
			ctx.setVariable("createproductMsg", request.getAttribute("createproductMsg"));
		
		templateEngine.process("/WEB-INF/EmployeeHome.html", ctx, response.getWriter());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	
	public void destroy() {
	}
}
