package controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import services.UserService;
import entities.User;
import exceptions.CredentialsException;
import javax.persistence.NonUniqueResultException;

@WebServlet("/CheckLogin")
public class CheckLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "services/UserService")
	private UserService usrService;

	public CheckLogin() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			
		String usrn = null;
		String pwd = null;
		
		try {
			usrn = StringEscapeUtils.escapeJava(request.getParameter("username"));
			pwd = StringEscapeUtils.escapeJava(request.getParameter("password"));
			if (usrn == null || pwd == null || usrn.isEmpty() || pwd.isEmpty()) {
				throw new CredentialsException("Missing or empty credential value");
			}
			
		} catch (CredentialsException e) {
			ServletContext servletContext = this.getServletContext();
			WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("loginErrorMsg", e.getMessage());
			
			// session not exist - user is in index.html
			if(request.getSession(false) == null) {
				templateEngine.process("/index.html", ctx, response.getWriter());
				return;
			}
			
			// session already exists and order created - user is in LogInSignIn.html
			else if(request.getSession(false) != null  &&  request.getSession().getAttribute("servicePackage") != null) {
				templateEngine.process("/WEB-INF/LogInSignIn.html", ctx, response.getWriter());
				return;
			}
		}
		
		
		User user = null;
		try {
			user = usrService.checkCredentials(usrn, pwd);
			
		} catch (CredentialsException | NonUniqueResultException e) {
			ServletContext servletContext = this.getServletContext();
			WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("loginErrorMsg", "Could not check credentials, please try again later");
			
			if(request.getSession(false) == null) {
				templateEngine.process("/index.html", ctx, response.getWriter());
				return;
			}
			
			else if (request.getSession(false) != null  &&  request.getSession().getAttribute("servicePackage") != null) {
				templateEngine.process("/WEB-INF/LogInSignIn.html", ctx, response.getWriter());
				return;
			}
		}

		// If the user exists, add info to the session and go to home page, otherwise
		// show login page with error message

		String path;
		if (user == null) {
			
			ServletContext servletContext = getServletContext();
			final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("loginErrorMsg", "Incorrect username or password");
			
			if(request.getSession(false) == null) {
				templateEngine.process("/index.html", ctx, response.getWriter());
				return;
			}
			
			else if (request.getSession(false) != null  &&  request.getSession().getAttribute("servicePackage") != null) {
				templateEngine.process("/WEB-INF/LogInSignIn.html", ctx, response.getWriter());
				return;
			}
			
		} else {
			
			// create a new session and set user attribute
			if(request.getSession(false) == null) {
				request.getSession().setAttribute("user", user);
				path = getServletContext().getContextPath() + "/Home";
				response.sendRedirect(path);
			}
			
			// session already exists - set user attribute and complete the order
			else if(request.getSession(false) != null  &&  request.getSession().getAttribute("servicePackage") != null){
				request.getSession().setAttribute("user", user);
				path = getServletContext().getContextPath() + "/GoToConfirmationPage";	/*Ritorna alla pagina di conferma prima di processare l'ordine*/		
				response.sendRedirect(path);
			}
		}
		
	}
	
	public void destroy() {
	}

}