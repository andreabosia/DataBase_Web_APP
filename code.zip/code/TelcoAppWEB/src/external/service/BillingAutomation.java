package external.service;

public class BillingAutomation {

	public BillingAutomation() {
		super();
	}
	
	
	public boolean attemptPayment(boolean makePaymentFail) {
		
		if(makePaymentFail == true)
			return false;
		
		return true;
	
	}

}
