use db_telco;


/*Number of total purchases per package*/
create table tot_purchases_package(
	id int not null auto_increment,
	service_package int not null,
	tot_purchases int not null default 0,
    foreign key (service_package) references service_package(id) on delete cascade on update cascade,
    primary key (id)
);

create trigger update_tot_purchases_package
after insert on activation_schedule
for each row
update tot_purchases_package 
	set tot_purchases = tot_purchases + 1
	where service_package = (select sp.id from service_package as sp, orders as ord 
											where new.id_order = ord.id and ord.id_servicepackage = sp.id);



/*Number of total purchases per package and validity period*/
create table tot_purchases_package_vperiod (
	id int not null auto_increment,
    service_package int not null,
    validity_period int not null,
    tot_purchases int not null default 0,
    foreign key (service_package) references service_package(id) on delete cascade on update cascade,
    foreign key (validity_period) references validity_period(id) on delete cascade on update cascade,
    primary key (id)
);

create trigger update_tot_purchases_package_vperiod
after insert on activation_schedule
for each row
update tot_purchases_package_vperiod
	set tot_purchases = tot_purchases + 1
	where service_package = (select sp.id from service_package as sp, orders as ord 
											where new.id_order = ord.id and ord.id_servicepackage = sp.id) and
		  validity_period = (select vp.id from validity_period as vp, orders as ord
											where new.id_order = ord.id and ord.id_validityperiod = vp.id);



/*Total value of sales per package with and without the optional products*/
create table tot_sales_package (
	id int not null auto_increment,
    service_package int not null,
    tot_sales decimal(7,2) not null default 0.00,
    sales_with_op_products decimal (7,2) not null default 0.00,
    foreign key (service_package) references service_package(id) on delete cascade on update cascade,
    primary key(id)
);

create trigger update_tot_sales_package
after insert on activation_schedule
for each row
update tot_sales_package
	set sales_with_op_products = sales_with_op_products + (select tot_amount from orders where id = new.id_order),
		tot_sales = tot_sales + (select vp.num_months*vp.monthly_fee from validity_period as vp, orders as ord where ord.id = new.id_order and ord.id_validityperiod = vp.id)
	where service_package = (select sp.id from service_package as sp, orders as ord 
											where new.id_order = ord.id and ord.id_servicepackage = sp.id);



/*Average number of optional products sold together with each service package*/
create table avg_optional_product (
	id int not null auto_increment,
    service_package int not null,
    avg_op_products int default 0,
    foreign key(service_package) references service_package(id) on delete cascade on update cascade,
    primary key(id)
);

# optional products sold for each order (in the activation schedule)
create view op_products_sold_per_order as (
	select act.id_order as id_order, sp.id as id_servicepackage, count(oop.id_order) as op_products_sold
	from activation_schedule as act left join order_optional_product as oop on act.id_order = oop.id_order, service_package as sp, orders as ord
    where ord.id = act.id_order and sp.id = ord.id_servicepackage
    group by act.id_order
);

create trigger update_avg_optional_product
after insert on activation_schedule
for each row
update avg_optional_product 
	set avg_op_products = (select avg(temp.op_products_sold) from op_products_sold_per_order as temp, orders as ord
							where new.id_order = ord.id and temp.id_servicepackage = ord.id_servicepackage)
	where service_package = (select sp.id from service_package as sp, orders as ord 
													where new.id_order = ord.id and ord.id_servicepackage = sp.id);



/*Best seller optional product, i.e. the optional product with the greatest value of sales across all the sold service packages*/
create table best_seller (
	id int default 1,
    op_product int,
    tot_sale decimal(5,2),
    foreign key(op_product) references optional_product(id) on delete cascade on update cascade,
    primary key(id)
);

delimiter $$
create trigger compute_best_seller
after insert on activation_schedule
for each row
begin
	if(new.id_order in (select id_order from order_optional_product)) then
		delete from best_seller where id = 1;
        
        insert into best_seller(op_product,tot_sale)
			(select op.id as op_product, sum(op.monthly_fee*vp.num_months) as tot_sale
			from optional_product as op, activation_schedule as act, order_optional_product as oop, orders as ord, validity_period as vp
			where  ord.id = act.id_order and oop.id_order = ord.id and op.id = oop.id_optionalproduct and vp.id = ord.id_validityperiod
			group by op.id
			order by tot_sale desc limit 1);
            
	end if;
end$$
delimiter ;


/*TRIGGER INSERT - INITIALIZE TABLES*/

delimiter $$
create trigger insert_service_package
after insert on service_package
for each row
begin
	insert into tot_purchases_package(id,service_package,tot_purchases) values(default, new.id, default);
	insert into tot_sales_package(id,service_package,tot_sales,sales_with_op_products) values(default, new.id, default, default);
	insert into avg_optional_product(id,service_package,avg_op_products) values(default, new.id, default);
end$$

delimiter ;

create trigger insert_tot_purchases_package_vperiod
after insert on service_package_validity_period
for each row
insert into tot_purchases_package_vperiod(id,service_package,validity_period,tot_purchases) values
(default, new.id_servicepackage, new.id_validityperiod, default);

